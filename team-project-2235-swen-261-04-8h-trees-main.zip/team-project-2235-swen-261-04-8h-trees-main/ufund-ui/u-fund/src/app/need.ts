export interface Need 
{
    id: number;
    name: string;
    cost: number;
    age: number;
    description: string;
}