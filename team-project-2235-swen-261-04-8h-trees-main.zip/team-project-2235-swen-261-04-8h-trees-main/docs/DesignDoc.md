---
geometry: margin=1in
---
# PROJECT Design Documentation

## Team Information
* Team name: Trees
* Team members
  * Nick Farsaci
  * Ryan Noyes
  * Zach Herring
  * Devin Rhodie

## Executive Summary

This project contains a web application that supports a charitable organization that helps donate and plant trees. A user on this site would log on, and find a selection of young trees that they can fund to be planted. They would have access to a funding basket, where they can select and insert tree(s) of their liking to fund. A user can also sort the trees by name, age, or cost on the page that contains the list of trees. Users, upon clicking a tree, can also view a detailed description of the tree. An administrator of the site, upon logging in, can view that same list of trees. They have the ability to add, remove, and modify the current visible list of trees. They do not have access to the funding basket. If they wish, they also can 'view' the website as a user.

### Purpose

The purpose of this project is to build a website that can support a charitable organization that helps donate and plant trees.

User Group - People who enjoy nature, or people who wish to support charitable organizations
User Goal - Help better environment, plant trees

### Glossary and Acronyms

| Term | Definition |
|------|------------|
| SPA | Single Page |
| URL | The address of a web page|


## Requirements

This section describes the features of the application.

### Definition of MVP

Sprint 2: The MVP, as of right now, consists of a basic web application that pulls from a list of needs managed by an administrator. The default URL leads to a login page, where upon log-in, will either show a user-view or an admin view. From this view, a user is able to view a list of needs contained within a database (within a json file). From there, they are able to add their desired needs to a cart, where they can proceed to checkout from there. If the admin-view is accessed, there will not be access to a funding basket. Instead, the admin will be able to view the needs and then modify the needs that are visible (add/delete/modify).

Sprint 4: The MVP consists of a basic web application that pulls from a list of needs managed by an administrator. The default URL leads to a login page, where upon login, will either show a user-view or an admin-view. From the user-view, a user is able to view a list of needs contained within a database (within a json file). The user can then add needs or delete needs from the cart or checkout and purchase the items. If the admin-view is accessed, there is no accesss to the cart. The admin will be able to view the needs and modify them (add/delete/modify). While in admin-view, the admin can change between the user-view and admin-view to make sure everything is showing up as intended.

### MVP Features

Login - As a user, I want to log-in to the website with my associated account, so that I can use the website according to whichever account I own. EPIC

Admin Login - As admin, I want to be able to have a specific login to access admin privileges in order to control the site. STORY

User Login - As a user I want to be able to have a login, so that I can preserve my basket through sessions. STORY

Admin Functionality - As an admin I want to be able to control the contents of the the cupboard so that I can add, delete, and change contents. EPIC

User - As a user, I want to be able to search for a specific tree name. EPIC

Add/Remove to Funding Basket - As a user, I want to add/remove needs to my funding basket, so that I can manage my basket. STORY

### Enhancements

Filter - This project includes a filter so that the user/admin can filter the list of needs by cost, name, or age.

Descriptions - This project includes a description box that appears after accessing a certain need. This includes scientific name, native range, appearance, habitat, and other important things relevant to the specific need.

## Application Domain

This section describes the application domain.

![Domain Model](team_domain_model_final.png)


Sprint 4: As of right now, the application has a model, controller and persistence tiers. Inside the model, there is a generic need class that contains basic information about the need: id, name, cost, age and description. This interacts with the NeedFileDAO, as well as the NeedDAO. The needDAO is an interface in which has all the basic calls for the need class, which then the actual implementation is within the needFileDAO. These are both within the persistence folder. The controller folder has a needController, which deals with the actual API calls and responses. There is also a need basket controller, which is to manage the need basket for the 'user' (similar to the need controller), as well as a funding basket DAO which implements the basic functions of the funding basket.

## Architecture and Design

This section describes the application architecture.

### Summary

![The Tiers & Layers of the Architecture](model.png)

The web application, is built using the Model–View–ViewModel (MVVM) architecture pattern. 

The Model stores the application data objects including any functionality to provide persistance. 

The View is the client-side SPA built with Angular utilizing HTML, CSS and TypeScript. The ViewModel provides RESTful APIs to the client (View) as well as any logic required to manipulate the data objects from the Model.

Both the ViewModel and Model are built using Java and Spring Framework. Details of the components within these tiers are supplied below.


### Overview of User Interface

This section describes the web interface flow; this is how the user views and interacts with the web application.

The default page a user will ecounter is the login page. Depending on how the user logs in (admin/user), they will be shown slightly different pages. The user will be shown a list of needs, and when clicked on, a short description of the need will be displayed to the side of the list. The user will have the option to add needs to their funding basket, which then can be viewed on a different page. Alternatively, the admin will not have the ability to add or view the cart. Instead, they will have the opportunity to see the user view, as well as the option to modify the visible list of needs (add/delete/modify). 


### View Tier

The view tier consists of many components. At first, a user is met with the default directory which is the login page. If the user is a normal user, they will log in and be given a specific token id that can only be used to access user pages. If a user attempts to access an admin page, they will be redirected back to the last page they had access to. Upon login, a user is met with the needs dashboard which lists all the needs. They have the ability to filter by name, cost, or age. When selecting a need, a detailed description of the selected need will be shown with it's name, age, cost. A user then has the ability to add the need to their cart, to which they can then have the ability to checkout. If an admin wants to log-in, they will have to have access to specific admin credentials. When an admin logs in, they have a similar needs dashboard as a normal user but with a few changes. First, they have no access to a cart. Then, they have the ability to add, delete, or modify needs. They also have the ability to access the needs dashboard as a user, but do not have the ability to add anything to cart or checkout.

![Cart-Sequence-Diagram](cart.png)
![Login-Sequence-Diagram](login.png)


### ViewModel Tier
Controller/Need Controller - Class that sends out the API request, and returns HTTP status' and Need objects
Controller/UserController - CLass that sends out API requests regarding user information, and returns HTTP status'

The Need and User Controller essentially carry out the same tasks, albeit handling different pieces of data. The user controller handles the API requests that come in from the View tier for our Need data, and passes the request to our NeedDAO. The User Controller does the same thing, but instead handles data related to user authentication and information. 

![View Model Tier](viewmodeltier.png)

### Model Tier

This tier is what handles all of our "stored" data, like our needs and User data. Both the needs and users are stored in JSON files, who then are called upon by their respective FileDAOs in order to pass back data that is requested from API requests.

Model/Need class - Handles data attributed to a need (Name, cost, id, age, description) as well as a few helper functions to get these values\
Model/User class- Handles data attributed to a User, as well as a few helper functions to get these values\
Persistence/NeedDAO - Public interface that defines the API functions dealing with Needs\
Persistence/NeedDAOFile - Class that reads/writes to the need JSON file (storage/inventory), and performs functions on it when the API is called\
Persistence/UserDAO - Public interface that defines the API functions dealing with Users\
Persistence UserFileDAO - Class that reads/writes to the user JSON file (storage/inventory), and performs functions on it when the API is called\

![Model Tier](modeltier.png) (in directory)

## OO Design Principles

Since the scope of the project is quite small at the moment, we were mainly thinking about Single Responsibility and how each class has it's own "job". We have elaborated on single responsibility, but we have also addressed dependency inversion by using several kinds of DAOs and FileDAOs with needs and users to handle API calls which are then handled in Angular with other classes designed around single responsibility. The DAOs also follow the Open/Closed principle, with the fileDAOs inheriting from their individual DAOs. We also to a point applied the Law of Demeter to our project by using components and services in our UI. Each component typically is something you see on the screen and they have limited knowledge of other components and only interact with other specific components like when going between the need list and the cart.

## Static Code Analysis/Future Design Improvements

1. Needing to change names of certain classes so that 
   they match other classes and the naming conventions are consistent throughout the project.
   ![Static Code Analysis API Issues](staticCodeAnalysis(1).png)

2. Needing to change some test classes to not public because they do not need to be delcared as so.
   ![Static Code Analysis API Issues](staticCodeAnalysis(2).png)

3. Changing a variable type from var to const so that there are no potential scope issues.
   ![Static Code Analysis UI Issues](staticCodeAnalysis(3).png)

4. Empty CSS files. To complete this issue, styles will be added into the CSS file.
   ![Static Code Analysis UI Issues](staticCodeAnalysis(4).png)


The team would try to design a better UI in terms of how things look to the user.

We would also try to get pictures set up to show on the website for each tree.

## Testing

### Acceptance Testing

Sprint 2: As of right now, we have no stories that are failing their acceptance criteria tests. The only user stories that have not had any testing should be the ones in the product backlog.

Sprint 4: Total of 20 Trello cards have been completed up until Sprint 4. 1 card in Sprint 4 is being worked on and 2 cards that have not been worked on at all.

### Unit Testing and Code Coverage

![Code Coverage](codecoveragesprint3.png)

We assigned each person certain tests to make. When we did the code coverage report we are only missing about 3 tests which none of us could figure out how to test for. Most of the issues were small syntax issues and once we fixed the syntax issues, we had about 95% code coverage and we were happy with that. When we were started the code coverage we were aiming for a minimum of 80% but a really good minimum of 90%.

## Ongoing Rationale

Sprint 1: 2024/21/2, We implemented the Needs.json, User.json and other files that began the foundation of the
project.\
Sprint 2: 2024/3/20 Around this time we mad many improvements to the project with .ts,.html,.spec ts, etc.\
Espically we figuring out how routing works we got the login page with the user and admin view.\
Sprint 3: 2024/4/8 Around here we made a cart and then made the website look better with css files. Then we figured out the filter like a couple of days after.
